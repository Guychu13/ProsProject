package com.example.pros;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class MainScreenActivity extends AppCompatActivity {

    private String username;
    private TextView userGreet;
    private ImageButton skinsButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen);
        skinsButton = findViewById(R.id.imageButton_mainScreen_skinsButton);
        skinsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainScreenActivity.this, SkinsScreenActivity.class));
            }
        });
    }

    public void onSettingsClick(View view){
        startActivity(new Intent(MainScreenActivity.this, SettingsScreenActivity.class));
    }

    @Override
    public void onBackPressed() {

    }


}
