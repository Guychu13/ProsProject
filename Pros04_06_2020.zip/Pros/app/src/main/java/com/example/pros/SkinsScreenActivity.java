package com.example.pros;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class SkinsScreenActivity extends AppCompatActivity {


    private String skinNamesArray[];
    private String skinMissionsArray[];
    private int images[] = {R.drawable.choose_username_button, R.drawable.choose_username_button, R.drawable.choose_username_button,
            R.drawable.choose_username_button, R.drawable.choose_username_button, R.drawable.choose_username_button, R.drawable.choose_username_button, R.drawable.choose_username_button};
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.skins_screen);

        skinNamesArray = getResources().getStringArray(R.array.skin_names);
        skinMissionsArray = getResources().getStringArray(R.array.skin_missions);
        recyclerView = findViewById(R.id.recyclerView_skinsScreen);
        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(getApplicationContext(), skinNamesArray, skinMissionsArray, images);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
    }
}
