package com.example.pros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsScreenActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private ImageButton logOutButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_screen);
        logOutButton = findViewById(R.id.imageButton_settingsScreen_loginButton);
    }

    public void onLogOut(View view){
        mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();
        startActivity(new Intent(SettingsScreenActivity.this, AfterLoadingActivity.class));
    }


    @Override
    public void onBackPressed() {
        Intent i = new Intent(SettingsScreenActivity.this, MainScreenActivity.class);
        finish();
        startActivity(i);
    }

}
