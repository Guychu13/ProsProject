package com.example.pros;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder>
{
    private Context context;
    private String names[];
    private String missions[];
    private int images[];

    public RecyclerAdapter(Context context, String[] names, String[] missions, int[] images) {
        this.context = context;
        this.names = names;
        this.missions = missions;
        this.images = images;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(this.context);
        View view = inflater.inflate(R.layout.recycler_view_skins_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textViewSkinName.setText(names[position]);
        holder.textViewSkinMission.setText(missions[position]);
        holder.image.setImageResource(images[position]);
    }

    @Override
    public int getItemCount() {
        return names.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textViewSkinName;
        TextView textViewSkinMission;
        ImageView image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewSkinName = itemView.findViewById(R.id.textView_skinsRow_name);
            textViewSkinMission = itemView.findViewById(R.id.textView_skinsRow_mission);
            image = itemView.findViewById(R.id.imageView_skinsRow_image);
        }
    }
}
